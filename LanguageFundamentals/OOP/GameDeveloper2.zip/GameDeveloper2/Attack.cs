public class Attack 
{
    public string Name;
    public int Damage;

    public Attack( string n, int d)
    {
        Name = n;
        Damage = d;
    }
}