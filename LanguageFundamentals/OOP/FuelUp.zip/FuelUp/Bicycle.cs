public class Bicycle : Ride{

    public Bicycle(string n, string c, int p = 1) : base (n, c, p, false){}
}